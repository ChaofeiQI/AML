# Copyright (c) OpenMMLab. All rights reserved.
from .meta_rcnn_res_layer import MetaRCNNResLayer

__all__ = ['MetaRCNNResLayer']
