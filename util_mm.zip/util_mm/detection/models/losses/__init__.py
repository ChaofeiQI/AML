# Copyright (c) OpenMMLab. All rights reserved.
from .supervised_contrastive_loss import SupervisedContrastiveLoss

__all__ = ['SupervisedContrastiveLoss']
