# Copyright (c) OpenMMLab. All rights reserved.
from typing import Tuple
from mmcv.cnn import build_conv_layer
from mmdet.models.builder import BACKBONES
from torch import Tensor
import torch, time, os
import numpy as np
from colorama import init, Fore
init()  # Init Colorama
from typing import List, Optional, Sequence, Tuple, Union
from mmengine.config import ConfigDict
from mmengine.structures import InstanceData, PixelData
from util_mm.detection.models.backbones._reslab import ResLab
# TODO: Need to avoid circular import with assigner and sampler
# Type hint of config data
ConfigType = Union[ConfigDict, dict]
OptConfigType = Optional[ConfigType]
# Type hint of one or more config data
MultiConfig = Union[ConfigType, List[ConfigType]]
OptMultiConfig = Optional[MultiConfig]
InstanceList = List[InstanceData]
OptInstanceList = Optional[InstanceList]
PixelList = List[PixelData]
OptPixelList = Optional[PixelList]
RangeType = Sequence[Tuple[int, int]]


@BACKBONES.register_module()
class MetaResLab(ResLab):
    """ResLab with `meta_conv` to handle different inputs in metarcnn and fsdetview.
    When input with shape (N, 3, H, W) from images, the network will use `conv1` as regular ResNet. 
    When input with shape (N, 4, H, W) from (image + mask) the network will replace `conv1` with `meta_conv` to handle additional channel.
    """
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.meta_conv_sup = build_conv_layer(
            self.conv_cfg,  # from config of ResNet
            6,
            64,
            kernel_size=7,
            stride=2,
            padding=3,
            groups=2,
            bias=False)
        self.meta_conv_qry = build_conv_layer(
            self.conv_cfg,  # from config of ResNet
            4,
            64,
            kernel_size=7,
            stride=2,
            padding=3,
            groups=2,
            bias=False)

    def RGB2LAB(self, image):
        # non negative
        image = torch.clamp(image, 0, None)
        image = torch.where(image > 0.0031308, 
                            1.055 * (image ** (1/2.4)) - 0.055, 12.92 * image)
        image *= 100.0

        # RGB to XYZ
        mat = torch.tensor([[0.4124564, 0.3575761, 0.1804375],
                            [0.2126729, 0.7151522, 0.0721750],
                            [0.0193339, 0.1191920, 0.9503041]], device=image.device)    
        xyz = torch.matmul(image, mat.T)
        xyz = torch.clamp(xyz, min=0)
        
        # XYZ to LAB
        xyz_ref = torch.tensor([95.047, 100.000, 108.883], device=image.device)
        xyz /= xyz_ref
        xyz = torch.where(xyz > 0.008856, xyz ** (1/3), (xyz * 7.787) + (16/116))
        l_c = 116 * xyz[..., 1] - 16
        a_c = 500 * (xyz[..., 0] - xyz[..., 1])
        b_c = 200 * (xyz[..., 1] - xyz[..., 2])
        
        # Normalize to [-1, 1]
        l_c = (l_c / 100) * 2 - 1
        a_c = (a_c + 88) / 176 * 2 - 1
        b_c = (b_c + 107) / 214 * 2 - 1
        
        # channels stack    
        lab = torch.stack([l_c, l_c, a_c, b_c], dim=-1)
        return lab

    def LAB_Batch(self, image_batch, **kwargs):
        batch_rgb = (image_batch + 1) / 2  # 将 [-1, 1] 转换为 [0, 1]
        # We offer a variety of strategies
        with torch.no_grad():
            batch_lab = self.RGB2LAB(batch_rgb.permute(0, 2, 3, 1))
            return batch_lab.permute(0, 3, 1, 2).to(image_batch.device)

    def LAB_with_mask(self, image_batch, **kwargs):
        batch_rgb = (image_batch[:,:3,:,:] + 1) / 2  # 将 [-1, 1] 转换为 [0, 1]
        # We offer a variety of strategies
        with torch.no_grad():
            batch_lab = self.RGB2LAB(batch_rgb.permute(0, 2, 3, 1))
            batch_lab = batch_lab.permute(0, 3, 1, 2)

            # 沿着第二个维度（索引为 1）进行拼接
            tensor_cat = torch.cat((batch_lab[:,:2,:,:], image_batch[:,3,:,:].unsqueeze(1),
                            batch_lab[:,2:,:,:], image_batch[:,3,:,:].unsqueeze(1)), dim=1)
            
            return tensor_cat.to(image_batch.device)

    
    def forward(self, x: Tensor, use_meta_conv: bool = False) -> Tuple[Tensor]:
        """Forward function.
        When input with shape (N, 3, H, W) from images, the network will use `conv1` as regular ResNet. 
        When input with shape (N, 4, H, W) from (image + mask) the network will replace `conv1` with `meta_conv` to handle additional channel.
        Args:
            x (Tensor): Tensor with shape (N, 3, H, W) from images or (N, 4, H, W) from (images + masks).
            use_meta_conv (bool): If set True, forward input tensor with `meta_conv` which require tensor with shape (N, 4, H, W).
                Otherwise, forward input tensor with `conv1` which require tensor with shape (N, 3, H, W). Default: False.
        Returns:
            tuple[Tensor]: Tuple of features, each item with shape (N, C, H, W).
        """
        # 归一化:
        # 找到张量中的绝对值最大值
        abs_max = torch.max(torch.abs(x))
        # 进行线性映射，将张量的值缩放到 [-1, 1] 范围
        scaled_x = x / abs_max

        # 空间变换：
        if len(x.shape) != 4:
            raise ValueError("X should be (N, C, H, W)")
        else: 
            if x.shape[1] == 3:
                input = self.LAB_Batch(scaled_x)
            elif x.shape[1] == 4:
                input = self.LAB_with_mask(scaled_x)

        # if torch.isnan(input).any() or torch.isinf(input).any():
        #     print("输入数据中存在 NaN 或 Inf 值")
        # else:
        #     print('Data is OK!')
        #     # print('111111:', input)
    
        # 第一个卷积层
        if use_meta_conv:
            x = self.meta_conv_sup(input)
        else:
            x = self.meta_conv_qry(input)
        x = self.norm1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        # 后续卷积层
        outs = []
        for i, layer_name in enumerate(self.res_layers):
            res_layer = getattr(self, layer_name)
            x = res_layer(x)
            if i in self.out_indices:
                outs.append(x)
        return tuple(outs)


if __name__ == "__main__":

    os.environ['CUDA_VISIBLE_DEVICES'] = '4'
    dummy_input = torch.randn(64, 3, 224, 224)  
    if dummy_input.shape[1]==4:
        meta_conv= True
    elif dummy_input.shape[1]==3:
        meta_conv= False
    t1=time.time()
    
    depth = 18   # [18, 34, 50, 101, 152]
    model = MetaResLab(depth=depth)
    print('model:',model)
    t2=time.time()

    for i in range(10):
        # outputs = model(dummy_input.cuda(), use_meta_conv=meta_conv)
        outputs = model(dummy_input, use_meta_conv=meta_conv)
        print('outputs:', outputs[-1].shape)                    # outputs: torch.Size([64, 512, 7, 7])
    t3=time.time()

    print('LabNet Instantiation(s):{:.6f}'.format(t2-t1)) 
    print('Testing Time Consuming(s):{:.6f}'.format(t3-t2))