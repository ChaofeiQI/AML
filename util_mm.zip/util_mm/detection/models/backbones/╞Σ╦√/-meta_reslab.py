# Copyright (c) OpenMMLab. All rights reserved.
from typing import Tuple
from mmcv.cnn import build_conv_layer
from mmdet.models.builder import BACKBONES
import torch, time, os
from torch import Tensor
# from mmdet.models import ResNet
# from .resnet import ResNet
from util_mm.detection.models.backbones.reslab import ResLab

# @BACKBONES.register_module()
class MetaResLab(ResLab):
    """ResNet with `meta_conv` to handle different inputs in metarcnn and fsdetview.
    When input with shape (N, 3, H, W) from images, the network will use `conv1` as regular ResNet. 
    When input with shape (N, 4, H, W) from (image + mask) the network will replace `conv1` with `meta_conv` to handle additional channel.
    """
    
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.meta_conv = build_conv_layer(
            self.conv_cfg,  # from config of ResNet
            6,
            72,
            kernel_size=7,
            stride=2,
            padding=3,
            groups=3,
            bias=False)

    def LAB_with_mask(self, image_batch, **kwargs):
        # 检查是否有可用的 GPU
        device = image_batch.device
        batch_rgb = image_batch[:, :3, :, :]

        # 使用 torch.no_grad() 上下文管理器避免梯度计算
        with torch.no_grad():
            # 直接在当前设备上进行计算
            batch_rgb_permuted = batch_rgb.permute(0, 2, 3, 1)
            batch_lab = self.RGB2LAB(batch_rgb_permuted)
            batch_lab = batch_lab.permute(0, 3, 1, 2)

            # 提取 mask 并添加维度
            mask = image_batch[:, 3, :, :].unsqueeze(1)

            # 沿着第二个维度（索引为 1）进行拼接
            tensor_cat = torch.cat((batch_lab[:, :1, :, :], mask,
                                    batch_lab[:, 1:2, :, :], mask,
                                    batch_lab[:, 2:, :, :], mask), dim=1)
            return tensor_cat.to(image_batch.device)

    def forward(self, x: Tensor, use_meta_conv: bool = False) -> Tuple[Tensor]:
        """Forward function.
        When input with shape (N, 3, H, W) from images, the network will use `conv1` as regular ResNet. 
        When input with shape (N, 4, H, W) from (image + mask) the network will replace `conv1` with `meta_conv` to handle additional channel.
        Args:
            x (Tensor): Tensor with shape (N, 3, H, W) from images or (N, 4, H, W) from (images + masks).
            use_meta_conv (bool): If set True, forward input tensor with `meta_conv` which require tensor with shape (N, 4, H, W).
                Otherwise, forward input tensor with `conv1` which require tensor with shape (N, 3, H, W). Default: False.
        Returns:
            tuple[Tensor]: Tuple of features, each item with shape (N, C, H, W).
        """
        # # 找到张量中的最大绝对值
        # abs_max = torch.max(torch.abs(x))
        # # 进行映射，将张量的值缩放到 [0, 1] 范围
        # x = (x / abs_max + 1) / 2
        
        if use_meta_conv:
            x = self.LAB_with_mask(x)
            x = self.base_conv(self.meta_conv(x))
        else:
            x = self.LAB_Batch(x)                   # LAB: torch.Size([64, 4, 224, 224])
            x = self.base_conv(self.conv1(x))
        x = self.norm1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        outs = []
        for i, layer_name in enumerate(self.res_layers):
            res_layer = getattr(self, layer_name)
            x = res_layer(x)
            if i in self.out_indices:
                outs.append(x)
        return tuple(outs)


if __name__ == "__main__":
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    dummy_input = torch.randn(64, 3, 224, 224)  
    # dummy_input = torch.randn(64, 4, 224, 224)  

    if dummy_input.shape[1]==4:
        meta_conv= True
    elif dummy_input.shape[1]==3:
        meta_conv= False
    t1=time.time()
    
    depth = 101   # [18, 34, 50, 101, 152]
    model = MetaResLab(depth=depth)
    model = model.cuda()
    print('model:',model)
    t2=time.time()

    for i in range(100):
        t11=time.time()
        outputs = model(dummy_input.cuda(), use_meta_conv=meta_conv)
        print('第{}次总耗时:{}s'.format(i, time.time()-t11))
        # print('outputs:', outputs[-1].shape)                    # outputs: torch.Size([64, 512, 7, 7])
    t3=time.time()

    print('MetaResLab Instantiation(s):{:.6f}'.format(t2-t1)) 
    print('Testing Time Consuming(s):{:.6f}'.format(t3-t2))
    
    
    ###############################
    # 打印网络详细指标
    ###############################
    from torchinfo import summary
    summary(model, input_size=(64, 3, 224, 224))
    '''
    ==========================================================================================
    Total params: 10,668,096
    Trainable params: 10,668,096
    Non-trainable params: 0
    Total mult-adds (G): 118.48
    ==========================================================================================
    Input size (MB): 38.54
    Forward/backward pass size (MB): 3827.83
    Params size (MB): 42.61
    Estimated Total Size (MB): 3908.97
    ==========================================================================================
    '''