# Copyright (c) OpenMMLab. All rights reserved.
from .custom_hook import ContrastiveLossDecayHook

__all__ = ['ContrastiveLossDecayHook']
